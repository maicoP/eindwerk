<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Free Hosting account activated! www.2freehosting.com</title>
<link rel="shortcut icon" type="image/x-icon" href="http://www.2freehosting.com/favicon.ico">
<meta content="text/html;charset=utf-8" http-equiv="Content-Type"/>
<meta name="author" content="2FreeHosting.com" />
<link href="http://www.2freehosting.com/style.css" rel="stylesheet" type="text/css"/>
<link rel="apple-touch-icon" sizes="57x57" href="http://www.2freehosting.com/images/fav/apple-touch-icon-57x57.png" />
<link rel="apple-touch-icon" sizes="114x114" href="http://www.2freehosting.com/images/fav/apple-touch-icon-114x114.png" />
<link rel="apple-touch-icon" sizes="72x72" href="http://www.2freehosting.com/images/fav/apple-touch-icon-72x72.png" />
<link rel="apple-touch-icon" sizes="144x144" href="http://www.2freehosting.com/images/fav/apple-touch-icon-144x144.png" />
<link rel="apple-touch-icon" sizes="60x60" href="http://www.2freehosting.com/images/fav/apple-touch-icon-60x60.png" />
<link rel="apple-touch-icon" sizes="120x120" href="http://www.2freehosting.com/images/fav/apple-touch-icon-120x120.png" />
<link rel="apple-touch-icon" sizes="76x76" href="http://www.2freehosting.com/images/fav/apple-touch-icon-76x76.png" />
<link rel="apple-touch-icon" sizes="152x152" href="http://www.2freehosting.com/images/fav/apple-touch-icon-152x152.png" />
<link rel="icon" type="image/png" href="http://www.2freehosting.com/images/fav/favicon-16x16.png" sizes="16x16" />
<link rel="icon" type="image/png" href="http://www.2freehosting.com/images/fav/favicon-32x32.png" sizes="32x32" />
<link rel="icon" type="image/png" href="http://www.2freehosting.com/images/fav/favicon-96x96.png" sizes="96x96" />
<link rel="icon" type="image/png" href="http://www.2freehosting.com/images/fav/favicon-160x160.png" sizes="160x160" />
<meta name="msapplication-TileColor" content="#469cce" />
<meta name="msapplication-TileImage" content="http://www.2freehosting.com/images/fav/mstile-144x144.png" />
<meta name="msapplication-square70x70logo" content="http://www.2freehosting.com/images/fav/mstile-70x70.png" />
<meta name="msapplication-square150x150logo" content="http://www.2freehosting.com/images/fav/mstile-150x150.png" />
<meta name="msapplication-square310x310logo" content="http://www.2freehosting.com/images/fav/mstile-310x310.png" />
<meta property="og:image" content="http://www.2freehosting.com/images/personazas.png" />
<!--[if IE 8]>
		<link rel="stylesheet" type="text/css" href="http://www.2freehosting.com/ie8.css">
	<![endif]-->
</head>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-5263515-14']);
  _gaq.push(['_setDomainName', '3eeweb.com']);
  _gaq.push(['_setDomainName', 'yzi.me']);
  _gaq.push(['_setDomainName', 'ciki.me']);
  _gaq.push(['_setDomainName', 'freeserver.me']);
  _gaq.push(['_setDomainName', 'twomini.com']);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);
  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<body class="background-white">
<div id="stick-head">
  <div class="head-box">
    <div class="logo text-shadow-dark">
      <div class="big-logo"> <a class="link" href="http://www.2freehosting.com/index.html">&nbsp;</a></div>
      <a class="link" href="http://www.2freehosting.com/index.html"><span>2FreeHosting.com</span></a></div>
    <div class="buttons">
      <div class="grey-button-small login-button"> <a href="http://cpanel.2freehosting.com/">Login</a></div>
      <div class="red-button-small sign-up-button"> <a class="link" href="http://www.2freehosting.com/signup.html">Sign Up</a></div>
    </div>
    <ul class="menu text-shadow-dark">
      <li><a class="link" href="http://www.2freehosting.com/reviews.html">Reviews</a></li>
      <li><a href="http://www.2freehosting.com/features.html">Features</a></li>
      <li><a href="http://www.2freehosting.com/forum/">Forum</a></li>
      <li><a href="http://www.2freehosting.com/faq.html">FAQ</a></li>
    </ul>
  </div>
</div>
<div id="main">
  <div id="container">
    <div class="space"></div>
    <div class="row">
      <h1>Your Free Hosting Account Activated!</h1>
    </div>
    <div class="row">
      <h4>Welcome</h4>
      <p class="preface">Thank you for choosing <a href="http://www.2freehosting.com" target="_blank">www.2freehosting.com</a> as your free web hosting provider! We wish you all the best with your new hosting account! People like us, connect with on on <b>Facebook</b> too!</p>
     <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fmyfreehosting&amp;width=800&amp;height=258&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false&amp;appId=253749334664501" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:900px; height:258px;" allowTransparency="true"></iframe>
      <h4>What to do now?</h4>
      <p class="preface">Ok, so you got your free hosting account and thinking on what to do next? Don't worry, we are here to help you!<br />
      First of all check your control panel and all the options it has on <a href="http://cpanel.2freehosting.com" target="_blank">cpanel.2freehosting.com</a>. There you will find all the information you need.<br />
      You can use a very cool Website Builder to build your website, Auto installer to install some Wordpress Blog for you or simply upload your existing website to public_html folder via local file manager or FTP client. Don't have an FTP client? Downlod Filezilla from <a href="https://filezilla-project.org/download.php" target="_blank">https://filezilla-project.org/download.php</a><br /><br />
      <b>Do not forget to delete this file - default.php</b><br /><br /></p>
      <h4>Need Help?</h4>
      <p class="preface">Still can't find what you are looking for? Contact us via help desk from the control panel or drop us a line from the <a href="http://www.2freehosting.com/contact.html" target="_blank">contacts page</a>. <a href="http://www.2freehosting.com/forum/">Or check our Support FORUMS HERE</a></p>
      <h4>Do NOT upload this</h4>
      <p class="preface">
      - Scam pages<br />
      - Fraud pages<br />
      - Any type of porn or adult pages<br />
      - Proxy sites<br />
      - Nulled scripts<br />
      - Shell scripts<br />
      - Copyrighted pages<br />
      - Anything else that is not legal
      </p>
      <h4>Connect with us</h4>
      <p class="preface">
      On <a href="http://www.2freehosting.com/forum/" target="_blank">Forum</a><br />
      On <a href="https://www.facebook.com/myfreehosting" target="_blank">Facebook</a><br />
      On <a href="https://plus.google.com/+2freehosting" target="_blank">Google+</a><br />
      On <a href="https://twitter.com/2freehosting" target="_blank">Twitter</a><br />
      On <a href="http://2freehosting.tumblr.com/" target="_blank">Tumblr</a><br />
      On <a href="http://www.youtube.com/user/2freehosting" target="_blank">YouTube</a><br />
      On <a href="http://vk.com/2freehosting" target="_blank">VK.COM</a>
      </p>
    </div>
    <div class="clear"> </div>
  </div>
  <div class="clear"> </div>
  <div class="footer-box">
    <div class="footer-box-inner">
      <div class="footer text-shadow-white">
        <div class="small-logo"> &nbsp;</div>
        <div class="text"> 2FREEHOSTING.COM © 2011 - 2014 <a href="http://www.2freehosting.com/privacy.html">Privacy Policy</a> <a href="http://www.2freehosting.com/tos.html">Terms Of Use</a></div>
        <div class="credits"> &nbsp;</div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
<!--DEFAULT_WELCOME_PAGE-->
